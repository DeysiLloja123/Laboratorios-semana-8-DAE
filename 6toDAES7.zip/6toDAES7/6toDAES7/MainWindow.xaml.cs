﻿using Business;
using Data;
using Entity;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _6toDAES7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            ProductBusiness business = new ProductBusiness();
            dgProduct.ItemsSource = business.Get();
        }
        private void Button_Click4(object sender, RoutedEventArgs e)
        {
            ProductBusiness business = new ProductBusiness();
            string productName = txtProductName.Text;
            dgProduct.ItemsSource = business.GetByName(productName);
        }

        private void Button_Click_InsertarProducto(object sender, RoutedEventArgs e)
        {
            try
            {
                // Crear una instancia de la clase Product con los datos del formulario
                Product product = new Product
                {
                    name = txtName.Text,
                    price = double.Parse(txtPrice.Text),
                    stock = int.Parse(txtStock.Text)
                };

                // Crear una instancia de la clase ProductBusiness y llamar al método Insert
                ProductBusiness business = new ProductBusiness();
                business.Insert(product);

                // Mostrar un mensaje de éxito
                MessageBox.Show("Producto insertado correctamente.");
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje de error si ocurre una excepción
                MessageBox.Show($"Error al insertar producto: {ex.Message}");
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (dgProduct.SelectedItem != null)
            {
                Product selectedProduct = dgProduct.SelectedItem as Product;

                MessageBoxResult result = MessageBox.Show("¿Estás seguro de que quieres eliminar este producto?",
                                                          "Confirmar Eliminación",
                                                          MessageBoxButton.YesNo,
                                                          MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    ProductData productData = new ProductData();
                    productData.Delete(selectedProduct.product_id);

                    LoadProducts();
                }
            }
            else
            {
                MessageBox.Show("Por favor selecciona un producto para eliminar.");
            }
        }

        private void LoadProducts()
        {
            ProductBusiness business = new ProductBusiness();
            dgProduct.ItemsSource = business.Get();
        }
    }


}
