﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public static class BaseDatos
    {
        public static string connectionString = "Data Source=LAB1504-28\\SQLEXPRESS;Initial Catalog=Factura;User Id=UserTecsup;Password=UserTecsup";
    }
}
